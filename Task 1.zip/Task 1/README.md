# MLOps Signal Generation Pipeline

Enterprise-grade batch processing pipeline for generating trading signals from OHLCV financial data using rolling mean crossover strategy. Built for production MLOps environments with comprehensive observability, reproducibility, and reliability.

## 🚀 Key Features

### Production-Ready Architecture
- **Deterministic Processing**: Configurable random seeds ensure reproducible results across environments
- **Comprehensive Observability**: Structured logging with detailed execution metrics and performance tracking
- **Robust Error Handling**: Graceful failure handling with structured error reporting
- **Container-Native**: Docker-optimized execution with embedded dependencies
- **CLI-First Design**: Production-ready command-line interface with comprehensive validation

### Enterprise MLOps Standards
- **Type Safety**: Full type hints for better code maintainability and IDE support
- **Structured Metrics**: JSON-formatted metrics output for monitoring and alerting systems
- **Comprehensive Validation**: Input validation, data quality checks, and configuration validation
- **Performance Monitoring**: Built-in latency tracking and resource utilization metrics
- **Audit Trail**: Complete execution logging for compliance and debugging

## 📊 Algorithm Overview

The pipeline implements a systematic approach to signal generation:

1. **Configuration Management**: Load and validate YAML configuration with type checking
2. **Data Ingestion**: CSV data loading with comprehensive validation and quality checks
3. **Feature Engineering**: Rolling mean computation with configurable window sizes
4. **Signal Generation**: Binary trading signals based on price-to-moving-average crossovers
5. **Performance Analytics**: Comprehensive metrics computation with detailed statistics
6. **Results Export**: Structured JSON output with execution metadata

## 🔧 Local Development

### Prerequisites

```bash
# System Requirements
Python 3.9+
pip package manager

# Optional: Docker for containerized execution
Docker Engine 20.10+
```

### Environment Setup

```bash
# Install dependencies
pip install -r requirements.txt

# Generate synthetic OHLCV dataset (deterministic with seed=42)
python generate_data.py
```

### Execution

```bash
# Run signal generation pipeline
python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log

# View execution results
cat metrics.json    # Performance metrics and results
cat run.log        # Detailed execution logs
```

## 🐳 Docker Deployment

### Container Build

```bash
# Build production container
docker build -t mlops-signal-pipeline .
```

### Container Execution

```bash
# Run containerized pipeline (outputs metrics to stdout)
docker run --rm mlops-signal-pipeline

# Extract execution artifacts
docker run --rm -v ${PWD}/output:/output mlops-signal-pipeline sh -c \
  "python run.py --input data.csv --config config.yaml --output /output/metrics.json --log-file /output/run.log"
```

## ⚙️ Configuration Management

### Configuration Schema (`config.yaml`)

```yaml
seed: 42          # Random seed for reproducibility (integer, >= 0)
window: 5         # Rolling window size for moving average (integer, > 0)
version: "v1"     # Pipeline version identifier (string)
```

### Reproducibility Guarantees

The pipeline ensures deterministic execution through:
- **Seeded Random Number Generation**: All stochastic operations use configurable seeds
- **Deterministic Data Processing**: Consistent ordering and processing logic
- **Version Tracking**: Configuration versioning for experiment reproducibility
- **Environment Isolation**: Docker containers provide consistent execution environments

## 📈 Observability & Monitoring

### Structured Logging

The pipeline provides comprehensive execution visibility:

```
2024-03-28 09:33:47,408 - INFO - === MLOps Signal Generation Job Started ===
2024-03-28 09:33:47,416 - INFO - Configuration loaded and validated - seed: 42, window: 5, version: v1
2024-03-28 09:33:47,479 - INFO - Data loaded and validated - 10000 total rows, 10000 valid close prices
2024-03-28 09:33:47,479 - INFO - Rolling mean computed - window: 5, valid values: 9996, NaN values: 4
2024-03-28 09:33:47,500 - INFO - Trading signals generated - valid signals: 9996, buy signals: 4914, sell/hold signals: 5082
2024-03-28 09:33:47,511 - INFO - Performance metrics computed - total_rows: 10000, valid_rows: 9996, signal_rate: 0.4914, buy_rate: 0.4914, latency: 92ms
2024-03-28 09:33:47,515 - INFO - === Job Completed Successfully - Total Latency: 92ms ===
```

### Metrics Schema

#### Success Response
```json
{
  "version": "v1",
  "rows_processed": 10000,
  "metric": "signal_rate",
  "value": 0.4914,
  "latency_ms": 92,
  "seed": 42,
  "status": "success"
}
```

#### Error Response
```json
{
  "version": "v1",
  "status": "error",
  "error_message": "Input CSV missing required 'close' column. Available columns: ['date', 'open', 'high', 'low', 'volume']"
}
```

### Key Performance Indicators

- **Signal Rate**: Proportion of buy signals generated (0.0 - 1.0)
- **Processing Latency**: End-to-end execution time in milliseconds
- **Data Quality**: Valid vs. invalid data points processed
- **Error Rate**: Structured error reporting with detailed diagnostics

## 🔍 Data Processing Logic

### Rolling Mean Computation
- **Window-based Calculation**: Configurable rolling window for moving average
- **NaN Handling**: First (window-1) rows produce NaN values and are excluded from signal computation
- **Data Quality Validation**: Comprehensive checks for missing or invalid price data

### Signal Generation Strategy
- **Binary Classification**: 1 (buy) when close price > rolling mean, 0 (sell/hold) otherwise
- **Valid Data Only**: Signals computed exclusively on non-NaN rolling mean values
- **Performance Tracking**: Detailed statistics on buy/sell signal distribution

## 🛡️ Quality Assurance

### Production Standards
- ✅ **Zero Hardcoded Paths**: Fully parameterized execution
- ✅ **Deterministic Results**: Identical outputs for same inputs and configuration
- ✅ **Comprehensive Error Handling**: Structured error metrics in all failure scenarios
- ✅ **Docker Compatibility**: Container execution without modifications
- ✅ **Type Safety**: Full type annotations for maintainability
- ✅ **Input Validation**: Comprehensive argument and data validation
- ✅ **Performance Monitoring**: Built-in latency and resource tracking

### Testing & Validation
- **Synthetic Data Generation**: Deterministic OHLCV dataset for consistent testing
- **Configuration Validation**: Type checking and range validation for all parameters
- **Data Quality Checks**: Comprehensive validation of input data structure and content
- **Error Scenario Testing**: Structured error handling for all failure modes

## 🚀 Performance Characteristics

- **Processing Speed**: ~100ms for 10,000 rows on standard hardware
- **Memory Efficiency**: Optimized pandas operations for large datasets
- **Scalability**: Linear scaling with input data size
- **Resource Usage**: Minimal CPU and memory footprint

## 📋 CLI Reference

```bash
python run.py --input INPUT_CSV --config CONFIG_YAML --output METRICS_JSON --log-file LOG_FILE

Arguments:
  --input     Input CSV file path containing OHLCV data (required)
  --config    Configuration YAML file path (required)
  --output    Output metrics JSON file path (required)
  --log-file  Log file path for detailed execution logs (required)

Examples:
  python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log
```

## 🏗️ Architecture & Design

### Modular Design
- **Separation of Concerns**: Clear separation between data loading, processing, and output
- **Error Isolation**: Comprehensive exception handling with graceful degradation
- **Extensibility**: Modular functions enable easy feature additions and modifications
- **Testability**: Pure functions with clear inputs/outputs for unit testing

### Production Considerations
- **Monitoring Integration**: JSON metrics format compatible with monitoring systems
- **Audit Compliance**: Complete execution logging for regulatory requirements
- **Resource Management**: Efficient memory usage and cleanup
- **Container Optimization**: Multi-stage Docker builds for minimal image size