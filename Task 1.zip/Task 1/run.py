#!/usr/bin/env python3
"""
MLOps Batch Job - Signal Generation from OHLCV Data

Production-ready batch processing pipeline that generates trading signals from OHLCV
financial data using rolling mean crossover strategy. Designed for enterprise MLOps
environments with comprehensive observability, error handling, and reproducibility.

Usage:
    python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log

Features:
    - Deterministic processing with configurable random seeds
    - Comprehensive structured logging and metrics
    - Robust error handling with graceful degradation
    - Production-ready CLI interface with validation
    - Docker-compatible execution environment
"""

import argparse
import json
import logging
import time
import sys
from pathlib import Path
from typing import Dict, Any, Tuple

import pandas as pd
import numpy as np
import yaml


def setup_logging(log_file: str) -> None:
    """
    Configure structured logging for production observability.
    
    Args:
        log_file: Path to log file for persistent logging
    """
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout)
        ]
    )
    logging.info("Logging system initialized")


def write_error_metrics(output_file: str, version: str, error_message: str) -> None:
    """
    Write structured error metrics to JSON output file.
    
    Args:
        output_file: Path to metrics output file
        version: Version identifier from config
        error_message: Detailed error description
    """
    error_metrics = {
        "version": version,
        "status": "error",
        "error_message": error_message
    }
    try:
        with open(output_file, 'w') as f:
            json.dump(error_metrics, f, indent=2)
        logging.info(f"Error metrics written to {output_file}")
    except Exception as e:
        logging.error(f"Failed to write error metrics: {str(e)}")


def validate_arguments(args: argparse.Namespace) -> None:
    """
    Validate CLI arguments for completeness and accessibility.
    
    Args:
        args: Parsed command line arguments
        
    Raises:
        ValueError: If arguments are invalid or files inaccessible
    """
    # Validate input file exists and is readable
    if not Path(args.input).exists():
        raise ValueError(f"Input file does not exist: {args.input}")
    
    if not Path(args.input).is_file():
        raise ValueError(f"Input path is not a file: {args.input}")
    
    # Validate config file exists and is readable
    if not Path(args.config).exists():
        raise ValueError(f"Config file does not exist: {args.config}")
    
    # Validate output directory is writable
    output_dir = Path(args.output).parent
    if not output_dir.exists():
        raise ValueError(f"Output directory does not exist: {output_dir}")
    
    logging.info("CLI arguments validated successfully")


def load_and_validate_config(config_file: str) -> Dict[str, Any]:
    """
    Load YAML configuration with comprehensive validation.
    
    Args:
        config_file: Path to YAML configuration file
        
    Returns:
        Validated configuration dictionary
        
    Raises:
        ValueError: If config is invalid or missing required keys
    """
    try:
        with open(config_file, 'r') as f:
            config = yaml.safe_load(f)
        
        if not isinstance(config, dict):
            raise ValueError("Config file must contain a YAML dictionary")
        
        # Validate required keys with type checking
        required_keys = {
            'seed': int,
            'window': int, 
            'version': str
        }
        
        missing_keys = []
        invalid_types = []
        
        for key, expected_type in required_keys.items():
            if key not in config:
                missing_keys.append(key)
            elif not isinstance(config[key], expected_type):
                invalid_types.append(f"{key} must be {expected_type.__name__}")
        
        if missing_keys:
            raise ValueError(f"Missing required config keys: {missing_keys}")
        
        if invalid_types:
            raise ValueError(f"Invalid config types: {invalid_types}")
        
        # Validate value ranges
        if config['window'] <= 0:
            raise ValueError("Window size must be positive")
        
        if config['seed'] < 0:
            raise ValueError("Seed must be non-negative")
        
        # Set random seed for reproducibility
        np.random.seed(config['seed'])
        
        logging.info(f"Configuration loaded and validated - seed: {config['seed']}, "
                    f"window: {config['window']}, version: {config['version']}")
        
        return config
        
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML format in config file: {str(e)}")
    except Exception as e:
        raise ValueError(f"Failed to load configuration: {str(e)}")


def load_and_validate_data(input_file: str) -> pd.DataFrame:
    """
    Load CSV data with comprehensive validation and error handling.
    
    Args:
        input_file: Path to input CSV file
        
    Returns:
        Validated pandas DataFrame
        
    Raises:
        ValueError: If data is invalid or missing required columns
    """
    try:
        # Read CSV with error handling
        df = pd.read_csv(input_file)
        
        # Validate data structure
        if df.empty:
            raise ValueError("Input CSV file contains no data")
        
        if 'close' not in df.columns:
            raise ValueError(f"Input CSV missing required 'close' column. "
                           f"Available columns: {list(df.columns)}")
        
        # Validate close column data quality
        if df['close'].isna().all():
            raise ValueError("Close column contains only NaN values")
        
        if (df['close'] <= 0).any():
            logging.warning("Close column contains non-positive values")
        
        nan_count = df['close'].isna().sum()
        if nan_count > 0:
            logging.warning(f"Close column contains {nan_count} NaN values")
        
        logging.info(f"Data loaded and validated - {len(df)} total rows, "
                    f"{len(df) - nan_count} valid close prices")
        
        return df
        
    except pd.errors.EmptyDataError:
        raise ValueError("Input CSV file is empty")
    except pd.errors.ParserError as e:
        raise ValueError(f"Failed to parse CSV file: {str(e)}")
    except Exception as e:
        raise ValueError(f"Failed to load data: {str(e)}")


def compute_rolling_mean(close_prices: pd.Series, window: int) -> pd.Series:
    """
    Compute rolling mean with detailed logging and validation.
    
    Args:
        close_prices: Series of close prices
        window: Rolling window size
        
    Returns:
        Rolling mean series with NaN for insufficient data points
    """
    if len(close_prices) < window:
        logging.warning(f"Data length ({len(close_prices)}) is less than window size ({window})")
    
    rolling_mean = close_prices.rolling(window=window, min_periods=window).mean()
    
    nan_count = rolling_mean.isna().sum()
    valid_count = len(rolling_mean) - nan_count
    
    logging.info(f"Rolling mean computed - window: {window}, "
                f"valid values: {valid_count}, NaN values: {nan_count}")
    
    return rolling_mean


def generate_trading_signal(close_prices: pd.Series, rolling_mean: pd.Series) -> pd.Series:
    """
    Generate binary trading signals with comprehensive validation.
    
    Args:
        close_prices: Series of close prices
        rolling_mean: Series of rolling mean values
        
    Returns:
        Binary signal series (1 for buy, 0 for sell/hold)
    """
    # Identify valid data points (non-NaN rolling mean)
    valid_mask = ~rolling_mean.isna()
    valid_count = valid_mask.sum()
    
    if valid_count == 0:
        logging.warning("No valid data points for signal generation")
        return pd.Series(dtype=int, index=close_prices.index)
    
    # Initialize signal series with NaN
    signal = pd.Series(index=close_prices.index, dtype='Int64')
    
    # Generate signals only for valid data points
    signal[valid_mask] = (close_prices[valid_mask] > rolling_mean[valid_mask]).astype(int)
    
    buy_signals = (signal == 1).sum()
    sell_signals = (signal == 0).sum()
    
    logging.info(f"Trading signals generated - valid signals: {valid_count}, "
                f"buy signals: {buy_signals}, sell/hold signals: {sell_signals}")
    
    return signal


def compute_performance_metrics(df: pd.DataFrame, signal: pd.Series, 
                               rolling_mean: pd.Series, config: Dict[str, Any], 
                               latency_ms: int) -> Dict[str, Any]:
    """
    Compute comprehensive performance metrics with detailed logging.
    
    Args:
        df: Original dataframe
        signal: Generated trading signals
        rolling_mean: Rolling mean values
        config: Configuration dictionary
        latency_ms: Processing latency in milliseconds
        
    Returns:
        Structured metrics dictionary
    """
    # Count rows processed (total input rows)
    total_rows = len(df)
    
    # Count valid signals (non-NaN rolling mean rows)
    valid_mask = ~rolling_mean.isna()
    valid_rows = valid_mask.sum()
    
    # Compute signal rate over valid rows only
    if valid_rows > 0:
        valid_signals = signal[valid_mask]
        signal_rate = valid_signals.mean()
        buy_rate = (valid_signals == 1).mean()
    else:
        signal_rate = 0.0
        buy_rate = 0.0
    
    metrics = {
        "version": config['version'],
        "rows_processed": total_rows,
        "metric": "signal_rate", 
        "value": round(signal_rate, 4),
        "latency_ms": latency_ms,
        "seed": config['seed'],
        "status": "success"
    }
    
    logging.info(f"Performance metrics computed - total_rows: {total_rows}, "
                f"valid_rows: {valid_rows}, signal_rate: {signal_rate:.4f}, "
                f"buy_rate: {buy_rate:.4f}, latency: {latency_ms}ms")
    
    return metrics


def print_metrics_to_stdout(metrics: Dict[str, Any]) -> None:
    """
    Safely print metrics to stdout for monitoring and debugging.
    
    Args:
        metrics: Metrics dictionary to print
    """
    try:
        print(json.dumps(metrics, indent=2))
    except Exception as e:
        logging.error(f"Failed to print metrics to stdout: {str(e)}")
        print(f'{{"status": "error", "error_message": "Failed to serialize metrics"}}')


def main() -> None:
    """
    Main entry point for MLOps batch processing pipeline.
    
    Orchestrates the complete signal generation workflow with comprehensive
    error handling, logging, and metrics collection.
    """
    # Parse and validate CLI arguments
    parser = argparse.ArgumentParser(
        description='MLOps Signal Generation Batch Job',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log
    
For more information, see README.md
        """
    )
    
    parser.add_argument('--input', required=True, 
                       help='Input CSV file path containing OHLCV data')
    parser.add_argument('--config', required=True,
                       help='Configuration YAML file path')
    parser.add_argument('--output', required=True,
                       help='Output metrics JSON file path')
    parser.add_argument('--log-file', required=True,
                       help='Log file path for detailed execution logs')
    
    args = parser.parse_args()
    
    # Initialize logging system
    setup_logging(args.log_file)
    
    # Record job start time for latency measurement
    start_time = time.time()
    logging.info("=== MLOps Signal Generation Job Started ===")
    
    config = None
    
    try:
        # Step 1: Validate CLI arguments
        validate_arguments(args)
        
        # Step 2: Load and validate configuration
        config = load_and_validate_config(args.config)
        
        # Step 3: Load and validate input data
        df = load_and_validate_data(args.input)
        
        # Step 4: Compute rolling mean
        rolling_mean = compute_rolling_mean(df['close'], config['window'])
        
        # Step 5: Generate trading signals
        signal = generate_trading_signal(df['close'], rolling_mean)
        
        # Step 6: Compute performance metrics
        end_time = time.time()
        latency_ms = int(round((end_time - start_time) * 1000))
        
        metrics = compute_performance_metrics(df, signal, rolling_mean, config, latency_ms)
        
        # Step 7: Write metrics to output file
        with open(args.output, 'w') as f:
            json.dump(metrics, f, indent=2)
        
        # Step 8: Print metrics to stdout for monitoring
        print_metrics_to_stdout(metrics)
        
        logging.info(f"=== Job Completed Successfully - Total Latency: {latency_ms}ms ===")
        
    except Exception as e:
        # Comprehensive error handling with structured metrics output
        error_message = str(e)
        logging.error(f"=== Job Failed: {error_message} ===")
        
        # Determine version for error metrics
        version = config.get('version', 'unknown') if config else 'unknown'
        
        # Write error metrics to output file
        write_error_metrics(args.output, version, error_message)
        
        # Print error metrics to stdout
        error_metrics = {
            "version": version,
            "status": "error", 
            "error_message": error_message
        }
        print_metrics_to_stdout(error_metrics)
        
        logging.info("=== Job Terminated with Error ===")
        sys.exit(1)


if __name__ == "__main__":
    main()