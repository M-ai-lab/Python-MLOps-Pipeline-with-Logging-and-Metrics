#!/usr/bin/env python3
"""
Generate synthetic OHLCV data for MLOps batch job testing.
Creates deterministic dataset using numpy seed=42.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def generate_ohlcv_data(n_rows=10000, seed=42):
    """Generate synthetic OHLCV data with deterministic random walk."""
    np.random.seed(seed)
    
    # Generate dates
    start_date = datetime(2023, 1, 1)
    dates = [start_date + timedelta(days=i) for i in range(n_rows)]
    
    # Generate close prices using cumulative random walk
    initial_price = 100.0
    returns = np.random.normal(0, 0.02, n_rows)  # 2% daily volatility
    close_prices = [initial_price]
    
    for i in range(1, n_rows):
        new_price = close_prices[-1] * (1 + returns[i])
        close_prices.append(max(new_price, 1.0))  # Prevent negative prices
    
    close_prices = np.array(close_prices)
    
    # Generate OHLC from close prices
    daily_volatility = 0.01  # 1% intraday volatility
    
    open_prices = []
    high_prices = []
    low_prices = []
    
    for i in range(n_rows):
        if i == 0:
            open_price = initial_price
        else:
            # Open is close of previous day with small gap
            gap = np.random.normal(0, 0.005)
            open_price = close_prices[i-1] * (1 + gap)
        
        # Generate high and low around open and close
        price_range = [open_price, close_prices[i]]
        min_price = min(price_range)
        max_price = max(price_range)
        
        # Add some intraday volatility
        high_noise = abs(np.random.normal(0, daily_volatility))
        low_noise = abs(np.random.normal(0, daily_volatility))
        
        high_price = max_price * (1 + high_noise)
        low_price = min_price * (1 - low_noise)
        
        open_prices.append(open_price)
        high_prices.append(high_price)
        low_prices.append(low_price)
    
    # Generate volume (random but realistic)
    volumes = np.random.lognormal(mean=10, sigma=1, size=n_rows).astype(int)
    
    # Create DataFrame
    df = pd.DataFrame({
        'date': dates,
        'open': np.round(open_prices, 2),
        'high': np.round(high_prices, 2),
        'low': np.round(low_prices, 2),
        'close': np.round(close_prices, 2),
        'volume': volumes
    })
    
    return df

if __name__ == "__main__":
    df = generate_ohlcv_data()
    df.to_csv('data.csv', index=False)
    print(f"Generated {len(df)} rows of OHLCV data to data.csv")
    print(f"Close price range: {df['close'].min():.2f} - {df['close'].max():.2f}")